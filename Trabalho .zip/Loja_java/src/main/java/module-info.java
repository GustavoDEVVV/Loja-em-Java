module Loja.java {
    requires java.sql;
    requires mysql.connector.java;
}